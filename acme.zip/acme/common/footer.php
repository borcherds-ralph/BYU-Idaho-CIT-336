    
    <footer>
        <hr>
        <p>&copy; ACME, All rights reserved</p>
        <p>All images used are believed to be in "Fair Use". Please notify the author if any are not and they will be removed.</p>
        <p>Last Updated: <span id="currentdate"><script>footerDate()</script></span></p>

    
    </footer>