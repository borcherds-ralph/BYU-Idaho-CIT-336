<!-- CSS files -->
    <!-- <link rel="stylesheet" href="<?php echo $basepath; ?>/css/normalize.css"> -->
    <link rel="stylesheet" href="<?php echo $basepath; ?>/css/style.css" media="screen">
    <!--  <link rel="stylesheet" href="<?php echo $basepath; ?>/css/fontawesome-all.css">  -->

    <!-- JavaScript files that have to load first -->
    <script src="<?php echo $basepath; ?>/js/scripts.js"></script>

    <script
        src="https://code.jquery.com/jquery-3.2.1.min.js"
        integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous"></script>
