<nav id="menu">
    <?php echo $navList; ?>
</nav>